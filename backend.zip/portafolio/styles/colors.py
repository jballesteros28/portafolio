from enum import Enum

class color(Enum):
    PRIMARY= "#163832"
    BACKGROUND= "#051F20"